function attachHandlers() {
    document.querySelector('form').addEventListener('submit', e => {
        e.preventDefault();
    });
    document.querySelector('#login button').addEventListener('click', login);
}

function access() {
    let user = document.getElementById('user');
    let guest = document.getElementById('guest');
    let name = document.querySelector('nav p span');

    if (!localStorage.getItem('token')) {
        user.style.display = 'none';
        guest.style.display = 'inline-block';
        name.textContent = 'guest';
    } else {
        user.style.display = 'inline-block';
        guest.style.display = 'none';
        name.textContent = localStorage.getItem('user');
    }
}

async function login() {
    let [email, password] = document.querySelectorAll('form input');

    let user = {
        email: email.value,
        password: password.value,
    };

    let options = {
        method: 'post',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(user),
    };

    try {
        let res = await fetch('http://localhost:3030/users/login', options);
        if (!res.ok) {
            let error = await res.json();
            throw error;
        }
        let data = await res.json();
        localStorage.setItem('token', data.accessToken);
        localStorage.setItem('user', data.email);
        localStorage.setItem('id', data._id);
        window.location.replace('./index.html');
    } catch (err) {
        document.querySelector('form p').textContent = err.message;
    }
}

attachHandlers();
access();
