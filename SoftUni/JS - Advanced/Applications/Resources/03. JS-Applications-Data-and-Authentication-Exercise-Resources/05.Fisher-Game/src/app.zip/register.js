function attachHandlers() {
    document.querySelector('form').addEventListener('submit', e => {
        e.preventDefault();
    });
    document.querySelector('form button').addEventListener('click', register);
}

function access() {
    if (localStorage.getItem('token')) {
        window.location.replace('./index');
    }
}

async function register() {
    let [email, password, repeat] = document.querySelectorAll('form input');

    try {
        if (email.value == '' || password.value == '') {
            throw new Error('Invalid email or password');
        }
        if (password.value != repeat.value) {
            throw new Error('Passwords must match');
        }

        let user = {
            email: email.value,
            password: password.value,
        };

        let options = {
            method: 'post',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        };

        let res = await fetch('http://localhost:3030/users/register', options);
        if (!res.ok) {
            let error = await res.json();
            throw error;
        }

        let data = await res.json();

        localStorage.setItem('token', data.accessToken);
        localStorage.setItem('user', data.email);
        localStorage.setItem('id', data._id);
        window.location.replace('./index.html');
    } catch (err) {
        document.querySelector('.notification').textContent = err.message;
    }
}

access();
attachHandlers();
